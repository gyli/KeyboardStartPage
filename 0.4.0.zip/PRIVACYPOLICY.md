# KeyboardStartPage Privacy Policy

_Last updated: February 20, 2022_

This Privacy Policy describes Our policies and procedures on the collection, use and disclosure of Your information when You use KeyboardStartPage.

KeyboardStartPage stores your configuration of this extension on local. It does not track or collect any data from you other than your input in options page.

KeyboardStartPage runs completely locally within your browser, and it does not contact any server. At no time will any of your stored personal data be sent to us or a third party. That's how it works. Period.
